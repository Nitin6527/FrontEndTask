import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  showParagraph= false;
  deleteRow=true;
  color="white"
  showCheck=false;
  colorCheck="white"

  display(){
    this.showParagraph=!this.showParagraph;
  }
  delete(){
    this.deleteRow=!this.deleteRow;
  }
  starToggle(){
    this.color="gold";
  }
  checkToggle(){
    this.colorCheck="green";
  }
  
}
