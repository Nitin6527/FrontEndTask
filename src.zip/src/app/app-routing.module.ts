import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerInfoComponent} from '../app/customer-info/customer-info.component';
import {ActivityLogComponent} from '../app/activity-log/activity-log.component';
import {PaymentsComponent} from '../app/payments/payments.component';

const routes: Routes = [
  {path: 'customer-info', component: CustomerInfoComponent},
  {path: 'active-log', component: ActivityLogComponent},
  {path: 'payments', component: PaymentsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
